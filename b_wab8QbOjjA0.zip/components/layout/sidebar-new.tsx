'use client';

import Link from 'next/link';
import { usePathname, useSearchParams } from 'next/navigation';
import { 
  ChevronRight, 
  Trophy, 
  Calendar, 
  Star, 
  BookOpen, 
  Users, 
  BarChart3, 
  Flame,
  TrendingUp,
  Zap
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { ALL_SPORTS, ALL_LEAGUES, BOOKMAKERS, getSportIcon } from '@/lib/sports-data';
import { ScrollArea } from '@/components/ui/scroll-area';

interface SidebarNewProps {
  selectedSportId?: number | null;
  onSelectSport?: (sportId: number | null) => void;
}

export function SidebarNew({ selectedSportId, onSelectSport }: SidebarNewProps) {
  const pathname = usePathname();
  const searchParams = useSearchParams();

  // Group sports by category
  const popularSports = ALL_SPORTS.filter(s => s.category === 'popular');
  const teamSports = ALL_SPORTS.filter(s => s.category === 'team');
  const individualSports = ALL_SPORTS.filter(s => s.category === 'individual');
  const combatSports = ALL_SPORTS.filter(s => s.category === 'combat');
  const racingSports = ALL_SPORTS.filter(s => s.category === 'racing');
  const otherSports = ALL_SPORTS.filter(s => s.category === 'other');

  // Get top leagues for selected sport
  const topLeagues = selectedSportId 
    ? ALL_LEAGUES.filter(l => l.sportId === selectedSportId).slice(0, 10)
    : ALL_LEAGUES.filter(l => l.tier === 1).slice(0, 10);

  return (
    <aside className="hidden w-64 shrink-0 border-r border-border bg-sidebar lg:block">
      <ScrollArea className="h-[calc(100vh-3.5rem)]">
        <div className="p-4">
          {/* Quick Stats */}
          <div className="mb-6 grid grid-cols-2 gap-2">
            <Link 
              href="/matches?status=live"
              className="rounded-lg bg-live/10 p-3 text-center transition-colors hover:bg-live/20"
            >
              <Flame className="mx-auto h-5 w-5 text-live" />
              <div className="mt-1 text-sm font-semibold text-live">Live</div>
              <div className="text-xs text-muted-foreground">12 matches</div>
            </Link>
            <Link 
              href="/leaderboard"
              className="rounded-lg bg-primary/10 p-3 text-center transition-colors hover:bg-primary/20"
            >
              <TrendingUp className="mx-auto h-5 w-5 text-primary" />
              <div className="mt-1 text-sm font-semibold text-primary">Hot Tips</div>
              <div className="text-xs text-muted-foreground">156 today</div>
            </Link>
          </div>

          {/* Popular Sports */}
          <div className="mb-6">
            <h3 className="mb-2 flex items-center gap-2 px-2 text-xs font-semibold uppercase tracking-wider text-sidebar-foreground/60">
              <Zap className="h-3 w-3" />
              Popular Sports
            </h3>
            <nav className="space-y-0.5">
              {popularSports.map((sport) => (
                <Link
                  key={sport.id}
                  href={`/matches?sport=${sport.slug}`}
                  onClick={() => onSelectSport?.(sport.id)}
                  className={cn(
                    'flex items-center justify-between rounded-lg px-2 py-2 text-sm transition-colors',
                    selectedSportId === sport.id
                      ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                      : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
                  )}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{getSportIcon(sport.slug)}</span>
                    <span>{sport.name}</span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-sidebar-foreground/40" />
                </Link>
              ))}
            </nav>
          </div>

          {/* All Sports Expandable */}
          <div className="mb-6">
            <details className="group">
              <summary className="mb-2 flex cursor-pointer items-center justify-between px-2 text-xs font-semibold uppercase tracking-wider text-sidebar-foreground/60">
                <span>All Sports ({ALL_SPORTS.length})</span>
                <ChevronRight className="h-3 w-3 transition-transform group-open:rotate-90" />
              </summary>
              <nav className="space-y-0.5">
                {/* Team Sports */}
                <div className="mb-3">
                  <div className="mb-1 px-2 text-[10px] font-medium uppercase text-sidebar-foreground/40">Team Sports</div>
                  {teamSports.map((sport) => (
                    <Link
                      key={sport.id}
                      href={`/matches?sport=${sport.slug}`}
                      className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm text-sidebar-foreground transition-colors hover:bg-sidebar-accent/50"
                    >
                      <span>{getSportIcon(sport.slug)}</span>
                      <span>{sport.name}</span>
                    </Link>
                  ))}
                </div>
                {/* Individual Sports */}
                <div className="mb-3">
                  <div className="mb-1 px-2 text-[10px] font-medium uppercase text-sidebar-foreground/40">Individual</div>
                  {individualSports.map((sport) => (
                    <Link
                      key={sport.id}
                      href={`/matches?sport=${sport.slug}`}
                      className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm text-sidebar-foreground transition-colors hover:bg-sidebar-accent/50"
                    >
                      <span>{getSportIcon(sport.slug)}</span>
                      <span>{sport.name}</span>
                    </Link>
                  ))}
                </div>
                {/* Combat Sports */}
                <div className="mb-3">
                  <div className="mb-1 px-2 text-[10px] font-medium uppercase text-sidebar-foreground/40">Combat</div>
                  {combatSports.map((sport) => (
                    <Link
                      key={sport.id}
                      href={`/matches?sport=${sport.slug}`}
                      className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm text-sidebar-foreground transition-colors hover:bg-sidebar-accent/50"
                    >
                      <span>{getSportIcon(sport.slug)}</span>
                      <span>{sport.name}</span>
                    </Link>
                  ))}
                </div>
                {/* Racing */}
                <div className="mb-3">
                  <div className="mb-1 px-2 text-[10px] font-medium uppercase text-sidebar-foreground/40">Racing</div>
                  {racingSports.map((sport) => (
                    <Link
                      key={sport.id}
                      href={`/matches?sport=${sport.slug}`}
                      className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm text-sidebar-foreground transition-colors hover:bg-sidebar-accent/50"
                    >
                      <span>{getSportIcon(sport.slug)}</span>
                      <span>{sport.name}</span>
                    </Link>
                  ))}
                </div>
                {/* Other */}
                <div>
                  <div className="mb-1 px-2 text-[10px] font-medium uppercase text-sidebar-foreground/40">Other</div>
                  {otherSports.map((sport) => (
                    <Link
                      key={sport.id}
                      href={`/matches?sport=${sport.slug}`}
                      className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-sm text-sidebar-foreground transition-colors hover:bg-sidebar-accent/50"
                    >
                      <span>{getSportIcon(sport.slug)}</span>
                      <span>{sport.name}</span>
                    </Link>
                  ))}
                </div>
              </nav>
            </details>
          </div>

          {/* Top Leagues */}
          <div className="mb-6">
            <h3 className="mb-2 px-2 text-xs font-semibold uppercase tracking-wider text-sidebar-foreground/60">
              Top Leagues
            </h3>
            <nav className="space-y-0.5">
              {topLeagues.map((league) => (
                <Link
                  key={league.id}
                  href={`/leagues/${league.slug}`}
                  className="flex items-center justify-between gap-2 rounded-lg px-2 py-1.5 text-sm text-sidebar-foreground transition-colors hover:bg-sidebar-accent/50"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-sm">{getCountryFlag(league.countryCode)}</span>
                    <span className="truncate">{league.name}</span>
                  </div>
                  <ChevronRight className="h-3 w-3 text-sidebar-foreground/40" />
                </Link>
              ))}
            </nav>
          </div>

          {/* Quick Links */}
          <div className="mb-6">
            <h3 className="mb-2 px-2 text-xs font-semibold uppercase tracking-wider text-sidebar-foreground/60">
              Quick Links
            </h3>
            <nav className="space-y-0.5">
              <Link
                href="/results"
                className={cn(
                  'flex items-center gap-2 rounded-lg px-2 py-2 text-sm transition-colors',
                  pathname === '/results'
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
                )}
              >
                <Calendar className="h-4 w-4" />
                <span>Results</span>
              </Link>
              <Link
                href="/tipsters"
                className={cn(
                  'flex items-center gap-2 rounded-lg px-2 py-2 text-sm transition-colors',
                  pathname === '/tipsters'
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
                )}
              >
                <Users className="h-4 w-4" />
                <span>Tipsters</span>
              </Link>
              <Link
                href="/leaderboard"
                className={cn(
                  'flex items-center gap-2 rounded-lg px-2 py-2 text-sm transition-colors',
                  pathname === '/leaderboard'
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
                )}
              >
                <Trophy className="h-4 w-4" />
                <span>Leaderboard</span>
              </Link>
              <Link
                href="/competitions"
                className={cn(
                  'flex items-center gap-2 rounded-lg px-2 py-2 text-sm transition-colors',
                  pathname === '/competitions'
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
                )}
              >
                <Star className="h-4 w-4" />
                <span>Competitions</span>
              </Link>
              <Link
                href="/bookmakers"
                className={cn(
                  'flex items-center gap-2 rounded-lg px-2 py-2 text-sm transition-colors',
                  pathname === '/bookmakers'
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
                )}
              >
                <BookOpen className="h-4 w-4" />
                <span>Bookmakers</span>
              </Link>
              <Link
                href="/stats"
                className={cn(
                  'flex items-center gap-2 rounded-lg px-2 py-2 text-sm transition-colors',
                  pathname === '/stats'
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
                )}
              >
                <BarChart3 className="h-4 w-4" />
                <span>Statistics</span>
              </Link>
            </nav>
          </div>

          {/* Featured Bookmakers */}
          <div>
            <h3 className="mb-2 px-2 text-xs font-semibold uppercase tracking-wider text-sidebar-foreground/60">
              Top Bookmakers
            </h3>
            <div className="space-y-2">
              {BOOKMAKERS.filter(b => b.featured).slice(0, 4).map((bookmaker) => (
                <a
                  key={bookmaker.id}
                  href={bookmaker.affiliateUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 rounded-lg border border-sidebar-border bg-sidebar-accent/30 px-3 py-2 text-sm transition-colors hover:bg-sidebar-accent"
                >
                  <div className="flex h-8 w-8 items-center justify-center rounded bg-background text-xs font-bold">
                    {bookmaker.name.charAt(0)}
                  </div>
                  <span className="font-medium text-sidebar-foreground">{bookmaker.name}</span>
                </a>
              ))}
            </div>
          </div>
        </div>
      </ScrollArea>
    </aside>
  );
}

// Country flag helper
function getCountryFlag(countryCode: string): string {
  const codeMap: Record<string, string> = {
    'GB-ENG': '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    'GB-SCT': '🏴󠁧󠁢󠁳󠁣󠁴󠁿',
    'EU': '🇪🇺',
    'WO': '🌍',
    'AF': '🌍',
    'AS': '🌏',
    'SA': '🇸🇦',
    'SH': '🌍',
    'CB': '🌴',
  };

  const mapped = codeMap[countryCode];
  if (mapped) return mapped;
  
  try {
    const codePoints = countryCode.substring(0, 2)
      .toUpperCase()
      .split('')
      .map(char => 127397 + char.charCodeAt(0));
    return String.fromCodePoint(...codePoints);
  } catch {
    return '🏳️';
  }
}
