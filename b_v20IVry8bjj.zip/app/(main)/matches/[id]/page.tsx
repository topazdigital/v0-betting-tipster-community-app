"use client"

import { use, useState, useMemo } from "react"
import Link from "next/link"
import { 
  ArrowLeft, Clock, Calendar, Radio, Users, TrendingUp, 
  MessageSquare, Share2, Bookmark, Star, CheckCircle2, XCircle
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { SPORTS_LIST } from "@/lib/sports-data"
import { format, addHours } from "date-fns"

interface PageProps {
  params: Promise<{ id: string }>
}

// Generate match data based on ID
function generateMatch(id: string) {
  const numId = parseInt(id.replace(/\D/g, '')) || 1
  const sport = SPORTS_LIST[numId % SPORTS_LIST.length]
  const statuses = ["scheduled", "live", "finished"] as const
  const status = statuses[numId % 3]
  
  return {
    id,
    sport: sport.name,
    sportIcon: sport.icon,
    league: sport.leagues[0],
    homeTeam: `Home Team ${numId}`,
    awayTeam: `Away Team ${numId}`,
    homeScore: status !== "scheduled" ? Math.floor(Math.random() * 5) : null,
    awayScore: status !== "scheduled" ? Math.floor(Math.random() * 5) : null,
    status,
    kickoff: addHours(new Date(), numId % 24 - 12),
    minute: status === "live" ? Math.floor(Math.random() * 90) : null,
    venue: "Stadium Arena",
    referee: "John Smith",
    weather: "Sunny, 22C",
    homeOdds: (1.5 + Math.random() * 2).toFixed(2),
    drawOdds: (2.5 + Math.random() * 2).toFixed(2),
    awayOdds: (2 + Math.random() * 3).toFixed(2),
    predictions: Math.floor(50 + Math.random() * 200),
    viewers: Math.floor(500 + Math.random() * 5000)
  }
}

const bookmakers = [
  { name: "Bet365", logo: "🎰", homeOdds: "1.85", drawOdds: "3.40", awayOdds: "4.20" },
  { name: "Betway", logo: "🎲", homeOdds: "1.90", drawOdds: "3.35", awayOdds: "4.10" },
  { name: "1xBet", logo: "🏆", homeOdds: "1.88", drawOdds: "3.45", awayOdds: "4.25" },
  { name: "William Hill", logo: "🎯", homeOdds: "1.83", drawOdds: "3.50", awayOdds: "4.30" },
  { name: "Unibet", logo: "⚡", homeOdds: "1.87", drawOdds: "3.38", awayOdds: "4.15" },
]

const tips = Array.from({ length: 8 }, (_, i) => ({
  id: i + 1,
  tipster: {
    name: `Tipster${i + 1}`,
    avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=tipster${i}`,
    winRate: 55 + Math.floor(Math.random() * 30),
    verified: i % 3 === 0
  },
  prediction: ["Home Win", "Away Win", "Draw", "Over 2.5", "BTTS Yes"][i % 5],
  odds: (1.5 + Math.random() * 2).toFixed(2),
  confidence: 60 + Math.floor(Math.random() * 35),
  analysis: "Based on recent form and head-to-head records, this is a strong pick.",
  likes: Math.floor(Math.random() * 100),
  createdAt: new Date(Date.now() - Math.random() * 24 * 60 * 60 * 1000)
}))

export default function MatchDetailPage({ params }: PageProps) {
  const { id } = use(params)
  const match = useMemo(() => generateMatch(id), [id])
  const [savedMatch, setSavedMatch] = useState(false)

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <Button variant="ghost" size="sm" asChild>
        <Link href="/matches">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Matches
        </Link>
      </Button>

      {/* Match Header Card */}
      <Card className="overflow-hidden">
        <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-2xl">{match.sportIcon}</span>
              <div>
                <p className="font-medium">{match.league}</p>
                <p className="text-sm text-muted-foreground">{match.venue}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {match.status === "live" && (
                <Badge variant="destructive" className="animate-pulse gap-1">
                  <Radio className="h-3 w-3" /> LIVE {match.minute}&apos;
                </Badge>
              )}
              {match.status === "scheduled" && (
                <Badge variant="secondary" className="gap-1">
                  <Clock className="h-3 w-3" /> {format(match.kickoff, "HH:mm")}
                </Badge>
              )}
              {match.status === "finished" && (
                <Badge className="bg-emerald-500 gap-1">
                  <CheckCircle2 className="h-3 w-3" /> FT
                </Badge>
              )}
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setSavedMatch(!savedMatch)}
              >
                <Bookmark className={cn("h-5 w-5", savedMatch && "fill-current")} />
              </Button>
              <Button variant="ghost" size="icon">
                <Share2 className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Teams & Score */}
          <div className="mt-8 flex items-center justify-center gap-8">
            <div className="flex-1 text-center">
              <div className="mx-auto mb-3 flex h-20 w-20 items-center justify-center rounded-full bg-card text-4xl shadow-lg">
                {match.sportIcon}
              </div>
              <h2 className="text-xl font-bold">{match.homeTeam}</h2>
              <p className="text-sm text-muted-foreground">Home</p>
            </div>
            
            <div className="text-center">
              {match.status !== "scheduled" ? (
                <div className="flex items-center gap-3">
                  <span className="text-5xl font-bold">{match.homeScore}</span>
                  <span className="text-2xl text-muted-foreground">-</span>
                  <span className="text-5xl font-bold">{match.awayScore}</span>
                </div>
              ) : (
                <div className="rounded-xl bg-card px-6 py-4 shadow-lg">
                  <p className="text-sm text-muted-foreground">Kickoff</p>
                  <p className="text-2xl font-bold">{format(match.kickoff, "HH:mm")}</p>
                  <p className="text-sm text-muted-foreground">{format(match.kickoff, "MMM d, yyyy")}</p>
                </div>
              )}
            </div>

            <div className="flex-1 text-center">
              <div className="mx-auto mb-3 flex h-20 w-20 items-center justify-center rounded-full bg-card text-4xl shadow-lg">
                {match.sportIcon}
              </div>
              <h2 className="text-xl font-bold">{match.awayTeam}</h2>
              <p className="text-sm text-muted-foreground">Away</p>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="mt-6 flex items-center justify-center gap-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              {match.viewers.toLocaleString()} watching
            </div>
            <div className="flex items-center gap-1">
              <TrendingUp className="h-4 w-4" />
              {match.predictions} predictions
            </div>
            <div className="flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              {format(match.kickoff, "EEE, MMM d")}
            </div>
          </div>
        </div>

        {/* Odds Summary */}
        <div className="grid grid-cols-3 gap-px border-t border-border bg-border">
          <button className="bg-card p-4 text-center transition-colors hover:bg-muted">
            <p className="text-sm text-muted-foreground">Home</p>
            <p className="text-xl font-bold text-primary">{match.homeOdds}</p>
          </button>
          <button className="bg-card p-4 text-center transition-colors hover:bg-muted">
            <p className="text-sm text-muted-foreground">Draw</p>
            <p className="text-xl font-bold text-primary">{match.drawOdds}</p>
          </button>
          <button className="bg-card p-4 text-center transition-colors hover:bg-muted">
            <p className="text-sm text-muted-foreground">Away</p>
            <p className="text-xl font-bold text-primary">{match.awayOdds}</p>
          </button>
        </div>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="odds" className="space-y-4">
        <TabsList className="w-full justify-start overflow-x-auto">
          <TabsTrigger value="odds">Odds Comparison</TabsTrigger>
          <TabsTrigger value="tips">Tips ({tips.length})</TabsTrigger>
          <TabsTrigger value="stats">Statistics</TabsTrigger>
          <TabsTrigger value="h2h">Head to Head</TabsTrigger>
        </TabsList>

        {/* Odds Comparison */}
        <TabsContent value="odds">
          <Card>
            <CardHeader>
              <CardTitle>Odds Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border text-left text-sm text-muted-foreground">
                      <th className="pb-3 font-medium">Bookmaker</th>
                      <th className="pb-3 text-center font-medium">Home</th>
                      <th className="pb-3 text-center font-medium">Draw</th>
                      <th className="pb-3 text-center font-medium">Away</th>
                    </tr>
                  </thead>
                  <tbody>
                    {bookmakers.map((bookie) => (
                      <tr key={bookie.name} className="border-b border-border last:border-0">
                        <td className="py-3">
                          <div className="flex items-center gap-2">
                            <span className="text-xl">{bookie.logo}</span>
                            <span className="font-medium">{bookie.name}</span>
                          </div>
                        </td>
                        <td className="py-3 text-center">
                          <span className="rounded-lg bg-muted px-3 py-1.5 font-bold text-primary">
                            {bookie.homeOdds}
                          </span>
                        </td>
                        <td className="py-3 text-center">
                          <span className="rounded-lg bg-muted px-3 py-1.5 font-bold text-primary">
                            {bookie.drawOdds}
                          </span>
                        </td>
                        <td className="py-3 text-center">
                          <span className="rounded-lg bg-muted px-3 py-1.5 font-bold text-primary">
                            {bookie.awayOdds}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tips */}
        <TabsContent value="tips">
          <div className="space-y-4">
            {tips.map((tip) => (
              <Card key={tip.id}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className="relative">
                      <img 
                        src={tip.tipster.avatar} 
                        alt={tip.tipster.name}
                        className="h-12 w-12 rounded-full"
                      />
                      {tip.tipster.verified && (
                        <div className="absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-blue-500">
                          <CheckCircle2 className="h-3 w-3 text-white" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold">{tip.tipster.name}</span>
                            <Badge variant="outline" className="text-xs">
                              {tip.tipster.winRate}% win rate
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {format(tip.createdAt, "MMM d, HH:mm")}
                          </p>
                        </div>
                        <div className="text-right">
                          <Badge className="bg-primary">{tip.prediction}</Badge>
                          <p className="mt-1 text-sm">
                            @ <span className="font-bold text-primary">{tip.odds}</span>
                          </p>
                        </div>
                      </div>
                      <p className="mt-3 text-muted-foreground">{tip.analysis}</p>
                      <div className="mt-3 flex items-center justify-between">
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Star className="h-4 w-4" /> {tip.confidence}% confidence
                          </span>
                          <span className="flex items-center gap-1">
                            <TrendingUp className="h-4 w-4" /> {tip.likes} likes
                          </span>
                        </div>
                        <Button variant="outline" size="sm">
                          Follow Tip
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Statistics */}
        <TabsContent value="stats">
          <Card>
            <CardHeader>
              <CardTitle>Match Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { label: "Possession", home: 58, away: 42 },
                  { label: "Shots", home: 12, away: 8 },
                  { label: "Shots on Target", home: 5, away: 3 },
                  { label: "Corners", home: 6, away: 4 },
                  { label: "Fouls", home: 10, away: 14 },
                ].map((stat) => (
                  <div key={stat.label}>
                    <div className="mb-1 flex items-center justify-between text-sm">
                      <span className="font-medium">{stat.home}</span>
                      <span className="text-muted-foreground">{stat.label}</span>
                      <span className="font-medium">{stat.away}</span>
                    </div>
                    <div className="flex h-2 overflow-hidden rounded-full bg-muted">
                      <div 
                        className="bg-primary" 
                        style={{ width: `${(stat.home / (stat.home + stat.away)) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Head to Head */}
        <TabsContent value="h2h">
          <Card>
            <CardHeader>
              <CardTitle>Head to Head</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {Array.from({ length: 5 }, (_, i) => {
                  const homeWon = Math.random() > 0.5
                  return (
                    <div key={i} className="flex items-center justify-between rounded-lg bg-muted/50 p-3">
                      <div className="text-sm text-muted-foreground">
                        {format(new Date(Date.now() - (i + 1) * 30 * 24 * 60 * 60 * 1000), "MMM d, yyyy")}
                      </div>
                      <div className="flex items-center gap-3">
                        <span className={cn("font-medium", homeWon && "text-emerald-500")}>
                          {match.homeTeam}
                        </span>
                        <span className="font-bold">
                          {homeWon ? "2" : "1"} - {homeWon ? "1" : "2"}
                        </span>
                        <span className={cn("font-medium", !homeWon && "text-emerald-500")}>
                          {match.awayTeam}
                        </span>
                      </div>
                      <Badge variant={homeWon ? "default" : "secondary"}>
                        {homeWon ? "H" : "A"}
                      </Badge>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
