"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { 
  Home, Calendar, Trophy, Users, BarChart3, Radio, Bookmark,
  Menu, X, Search, Bell, Settings, LogIn, ChevronDown,
  TrendingUp, Star, Wallet, HelpCircle
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"
import { SPORTS_LIST } from "@/lib/sports-data"

const mainNavItems = [
  { href: "/", label: "Home", icon: Home },
  { href: "/live", label: "Live", icon: Radio, badge: "12" },
  { href: "/matches", label: "Matches", icon: Calendar },
  { href: "/tipsters", label: "Tipsters", icon: Users },
  { href: "/leaderboard", label: "Leaderboard", icon: Trophy },
  { href: "/competitions", label: "Competitions", icon: Star },
  { href: "/bookmakers", label: "Bookmakers", icon: Wallet },
  { href: "/results", label: "Results", icon: BarChart3 },
]

export default function MainLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [showSports, setShowSports] = useState(true)

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 left-0 z-50 w-64 transform border-r border-border bg-card transition-transform lg:translate-x-0",
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        {/* Logo */}
        <div className="flex h-16 items-center justify-between border-b border-border px-4">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white font-bold">
              BT
            </div>
            <span className="text-lg font-bold">BetTips Pro</span>
          </Link>
          <Button 
            variant="ghost" 
            size="icon" 
            className="lg:hidden"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Navigation */}
        <nav className="space-y-1 p-3">
          {mainNavItems.map((item) => {
            const isActive = pathname === item.href
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setSidebarOpen(false)}
                className={cn(
                  "flex items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                  isActive 
                    ? "bg-primary text-primary-foreground" 
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                )}
              >
                <div className="flex items-center gap-3">
                  <item.icon className="h-5 w-5" />
                  {item.label}
                </div>
                {item.badge && (
                  <span className={cn(
                    "flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-xs font-bold",
                    isActive ? "bg-white/20 text-white" : "bg-red-500 text-white"
                  )}>
                    {item.badge}
                  </span>
                )}
              </Link>
            )
          })}
        </nav>

        {/* Sports Section */}
        <div className="border-t border-border p-3">
          <button 
            onClick={() => setShowSports(!showSports)}
            className="flex w-full items-center justify-between px-3 py-2 text-sm font-semibold text-muted-foreground"
          >
            Sports
            <ChevronDown className={cn("h-4 w-4 transition-transform", showSports && "rotate-180")} />
          </button>
          {showSports && (
            <div className="mt-1 max-h-64 space-y-0.5 overflow-y-auto scrollbar-hide">
              {SPORTS_LIST.slice(0, 15).map((sport) => (
                <Link
                  key={sport.id}
                  href={`/matches?sport=${sport.id}`}
                  onClick={() => setSidebarOpen(false)}
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                >
                  <span className="text-lg">{sport.icon}</span>
                  {sport.name}
                </Link>
              ))}
            </div>
          )}
        </div>

        {/* Admin Link */}
        <div className="absolute bottom-0 left-0 right-0 border-t border-border p-3">
          <Link
            href="/admin"
            className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <Settings className="h-5 w-5" />
            Admin Panel
          </Link>
        </div>
      </aside>

      {/* Main Content */}
      <div className="lg:pl-64">
        {/* Header */}
        <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b border-border bg-card/95 px-4 backdrop-blur supports-[backdrop-filter]:bg-card/60">
          <Button 
            variant="ghost" 
            size="icon" 
            className="lg:hidden"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </Button>

          {/* Search */}
          <div className="relative hidden flex-1 max-w-md md:block">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input 
              placeholder="Search matches, tipsters, teams..." 
              className="pl-9 bg-muted/50 border-0"
            />
          </div>

          {/* Mobile Logo */}
          <Link href="/" className="flex items-center gap-2 lg:hidden">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 text-white text-sm font-bold">
              BT
            </div>
          </Link>

          <div className="ml-auto flex items-center gap-2">
            {/* Mobile Search */}
            <Button variant="ghost" size="icon" className="md:hidden">
              <Search className="h-5 w-5" />
            </Button>

            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] text-white">
                3
              </span>
            </Button>

            <Button variant="ghost" size="icon">
              <Bookmark className="h-5 w-5" />
            </Button>

            <Button className="hidden gap-2 md:flex">
              <LogIn className="h-4 w-4" />
              Sign In
            </Button>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-4 pb-24 md:p-6 lg:p-8 lg:pb-8">
          {children}
        </main>

        {/* Footer */}
        <footer className="hidden border-t border-border bg-card px-4 py-8 lg:block lg:ml-0">
          <div className="mx-auto max-w-7xl">
            <div className="grid gap-8 md:grid-cols-4">
              <div>
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 text-white text-sm font-bold">
                    BT
                  </div>
                  <span className="font-bold">BetTips Pro</span>
                </div>
                <p className="mt-3 text-sm text-muted-foreground">
                  Your trusted source for professional betting tips and predictions across 30+ sports.
                </p>
              </div>
              <div>
                <h4 className="mb-3 font-semibold">Quick Links</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li><Link href="/matches" className="hover:text-foreground">Matches</Link></li>
                  <li><Link href="/tipsters" className="hover:text-foreground">Tipsters</Link></li>
                  <li><Link href="/leaderboard" className="hover:text-foreground">Leaderboard</Link></li>
                  <li><Link href="/results" className="hover:text-foreground">Results</Link></li>
                </ul>
              </div>
              <div>
                <h4 className="mb-3 font-semibold">Sports</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  {SPORTS_LIST.slice(0, 5).map(sport => (
                    <li key={sport.id}>
                      <Link href={`/matches?sport=${sport.id}`} className="hover:text-foreground">
                        {sport.icon} {sport.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="mb-3 font-semibold">Support</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li><Link href="/help" className="hover:text-foreground">Help Center</Link></li>
                  <li><Link href="/contact" className="hover:text-foreground">Contact Us</Link></li>
                  <li><Link href="/terms" className="hover:text-foreground">Terms of Service</Link></li>
                  <li><Link href="/privacy" className="hover:text-foreground">Privacy Policy</Link></li>
                </ul>
              </div>
            </div>
            <div className="mt-8 border-t border-border pt-6 text-center text-sm text-muted-foreground">
              <p>&copy; {new Date().getFullYear()} BetTips Pro. All rights reserved.</p>
              <p className="mt-1">Gamble responsibly. 18+</p>
            </div>
          </div>
        </footer>
      </div>

      {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-border bg-card lg:hidden">
        <div className="flex items-center justify-around py-2">
          {[
            { href: "/", label: "Home", icon: Home },
            { href: "/live", label: "Live", icon: Radio },
            { href: "/matches", label: "Matches", icon: Calendar },
            { href: "/tipsters", label: "Tipsters", icon: Users },
            { href: "/leaderboard", label: "More", icon: Trophy },
          ].map((item) => {
            const isActive = pathname === item.href
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex flex-col items-center gap-1 px-3 py-1.5",
                  isActive ? "text-primary" : "text-muted-foreground"
                )}
              >
                <item.icon className="h-5 w-5" />
                <span className="text-[10px] font-medium">{item.label}</span>
              </Link>
            )
          })}
        </div>
      </nav>
    </div>
  )
}
